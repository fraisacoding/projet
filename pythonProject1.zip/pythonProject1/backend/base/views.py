from django.shortcuts import render
from django.views import View
from .models import Product
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializers import ProductSerializer

# Create your views here.
class Home(View):
    def get(self,request):
        return render(request,'home.html',{})
class ProductList(APIView):
    def get(self,request):
        #récuperer depuis db
        products=Product.objects.all()
        serializer=ProductSerializer(products,many=True)
        #return render(request,'listProducts.html',{'prod':produits})
        return Response(serializer.data)
class ProductDetails(APIView):
    def get(self,request,idprod):
        produit=Product.objects.get(id=idprod)
        serializer = ProductSerializer(produit, many=True)
        #return render(request,'details.html',{'prod':produit})
        return Response(serializer.data)
'''class ProductBasket(View):
    def get(self,request,idpanier):
        produit=Product.objects.get(id=idpanier)
        return render(request,'Basket.html',{'prod':produit})
'''
